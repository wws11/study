package com.gysoft.spring.bean;

import lombok.Data;

/**
 * @Description
 * @Author DJZ-WWS
 * @Date 2019/4/2 10:57
 */

@Data
public class User {


    private  String  id;
    private  String password;
    private  String userName;


}
