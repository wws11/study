package com.gysoft.spring.beanpost;

/**
 * @Description
 * @Author DJZ-WWS
 * @Date 2019/5/7 16:37
 */
public class OtherTest {
    public static void main(String[] args) {

        System.out.println(OneBean.class);
    }
}
